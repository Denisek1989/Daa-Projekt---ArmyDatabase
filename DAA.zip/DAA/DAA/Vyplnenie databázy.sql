INSERT INTO `t_rank`(
	`rank`
)
VALUES ('Private'),
		 ('Corporal'),
		 ('Sergeant'),
		 ('Sergeant Major'),
		 ('Lieutenant'),
		 ('Captain'),
		 ('Major'),
		 ('Officer'),
		 ('Major General'),
		 ('General');
		
INSERT INTO `t_role`(
	`role`
)
VALUES ('Rifleman'),
		 ('Sniper'),
		 ('Instructor'),
		 ('Driver'),
		 ('Pilot'),
		 ('Scout'),
		 ('SpecOps'),
		 ('Mechanic'),
		 ('Grenadier'),
		 ('Copilot'),
		 ('Leader'),
		 ('Medic');
		
INSERT INTO `type`(
	`type`
)
VALUES ('Tank'),
		 ('Jeep'),
		 ('Motorbike'),
		 ('ATV'),
		 ('APC'),
		 ('AA'),
		 ('Truck'),
		 ('Jet'),
		 ('Helicopter'),
		 ('Aircraft ship'),
		 ('Ship'),
		 ('Battleship');
		
INSERT INTO `base`(
	`location`,
	`capacity`
)
VALUES ('Japan', '500'),
('Russia', '250'),
('Spain', '300'),
('China', '586'),
('France', '458'),
('Turkey', '359'),
('Usa', '589'),
('Mexico', '875'),
('Slovakia', '358'),
('Germany', '320');
		 
INSERT INTO `armory`(
	`ammo_boxes`,
	`gas_cans`,
   `missiles`,
	`assault_rifles`,
	`sidearms`,
	`tactical_vests`,
   `flashlights`,
   `a_base_id`
)
VALUES ('500','600','250','250','250','250','258','1'),
		 ('520','620','260','270','280','240','250','2'),
		 ('502','602','252','252','252','252','262','3'),
		 ('520','603','251','255','258','254','268','5'),
		 ('580','670','290','240','260','270','280','7'),
		 ('510','610','210','210','210','210','220','6'),
		 ('530','630','230','230','230','230','230','4'),
		 ('580','680','280','280','280','280','280','8'),
		 ('570','670','270','270','240','270','230','9'),
		 ('530','640','270','280','250','286','298','7');
		
INSERT INTO `soldier`(
	`s_name`,
	`age`,
   `s_rank`,
	`s_role`,
   `active`,
   `s_base_id`
)
VALUES ('Josh','25','1','1','1','3'),
		 ('Carl','28','1','5','1','4'),
		 ('Mack','27','3','6','1','2'),
		 ('John','24','2','7','0','1'),
		 ('Neil','27','4','4','1','4'),
		 ('Matt','25','1','9','1','3'),
		 ('Daniel','24','5','7','0','5'),
		 ('Max','22','1','2','1','4'),
		 ('Andrew','32','8','11','1','7'),
		 ('Tom','27','4','9','1','6');
		 
	
INSERT INTO `vechicle`(
	`v_name`,
	`v_type`,
   `v_condition`,
   `v_base_id`,
   `soldier_id`
)
VALUES ('BigBOB','1','plne funkčný','1','3'),
       ('Sword','3','plne funkčný','2','6'),
       ('Monkey','2','plne funkčný','7','4'),
       ('BadWolf','6','plne funkčný','4','5'),
       ('Indian','7','nefunkčný rotor','2','7'),
       ('Abraham','12','plne funkčný','4','3'),
       ('Cloud','6','poškodená nádrž','6','2'),
       ('Headshot','11','plne funkčný','1','8'),
       ('Terminator','1','poškodený pancier','6','1'),
       ('Kakashi','7','zničený zadná rotor','8','9');
		 
		 
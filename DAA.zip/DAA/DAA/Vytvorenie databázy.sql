CREATE DATABASE AB;
USE ab;
CREATE TABLE `t_rank` (
   `ra_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`rank` CHAR(50) NULL DEFAULT NULL,
	PRIMARY KEY (`ra_id`) USING BTREE
	);
	
CREATE TABLE `type` (
   `t_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`type` CHAR(50) NULL DEFAULT NULL,
	PRIMARY KEY (`t_id`) USING BTREE
);

CREATE TABLE `t_role` (
   `ro_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`role` CHAR(50) NULL DEFAULT NULL,
	PRIMARY KEY (`ro_id`) USING BTREE
);

CREATE TABLE `base` (
   `b_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`location` CHAR(50) NULL DEFAULT NULL,
   `capacity` INT(10) NULL DEFAULT NULL,
	PRIMARY KEY (`b_id`) USING BTREE
);

CREATE TABLE `armory` (
   `a_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
   `ammo_boxes` INT(10) NULL DEFAULT NULL,
   `gas_cans` INT(10) NULL DEFAULT NULL,
   `missiles` INT(10) NULL DEFAULT NULL,
   `assault_rifles` INT(10) NULL DEFAULT NULL,
   `sidearms` INT(10) NULL DEFAULT NULL,
   `tactical_vests` INT(10) NULL DEFAULT NULL,
   `flashlights` INT(10) NULL DEFAULT NULL,
   `a_base_id` INT(10) UNSIGNED NULL DEFAULT NULL,
	PRIMARY KEY (`a_id`) USING BTREE,
	FOREIGN KEY (`a_base_id`) REFERENCES `base` (`b_id`)
);
	
	CREATE TABLE `soldier` (
   `s_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`s_name` CHAR(50) NULL DEFAULT NULL,
   `age` INT(10) NULL DEFAULT NULL,
   `s_rank` INT(10) UNSIGNED NULL DEFAULT NULL,
   `s_role` INT(10) UNSIGNED NULL DEFAULT NULL,
   `active` INT(10) NULL DEFAULT NULL,
   `s_base_id` INT(10) UNSIGNED NULL DEFAULT NULL,
	PRIMARY KEY (`s_id`) USING BTREE,
	FOREIGN KEY (`s_rank`) REFERENCES `t_rank` (`ra_id`),
	FOREIGN KEY (`s_role`) REFERENCES `t_role` (`ro_id`),
	FOREIGN KEY (`s_base_id`) REFERENCES `base` (`b_id`)
);
	
	CREATE TABLE `vechicle` (
   `v_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`v_name` CHAR(50) NULL DEFAULT NULL,
   `v_type` INT(10) UNSIGNED NULL DEFAULT NULL,
   `v_condition` CHAR(50) NULL DEFAULT NULL,
   `v_base_id` INT(10) UNSIGNED NULL DEFAULT NULL,
   `soldier_id` INT(10) UNSIGNED NULL DEFAULT NULL,
	PRIMARY KEY (`v_id`) USING BTREE,
	FOREIGN KEY (`v_base_id`) REFERENCES `base` (`b_id`),
	FOREIGN KEY (`soldier_id`) REFERENCES `soldier` (`s_id`),
	FOREIGN KEY (`v_type`) REFERENCES `type` (`t_id`)
);
	

	
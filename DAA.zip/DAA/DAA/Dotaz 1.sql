/*Č. 1, Vyberie všetky hodnoty z tabuľky soldier a zoradí ich podľa age od najmladšieho po najstaršieho*/
SELECT * FROM soldier ORDER BY s_rank;

/*Č. 2, Vyberie všetký údaje vojakov, ktorí majú menej alebo 25 rokov a zoradí ich od najmladšieho*/
SELECT * FROM soldier WHERE age <=25  ORDER BY age;

/*Č. 3, Vyberie lokacie z base a zoradí ich podľa ich kapacity od najväčšej po najmenšiu*/
SELECT location FROM base ORDER BY capacity DESC;

/*Č. 4, Vyberie údaje o počte boxov s nábojmi v armory a zoradí ich podľa base_id základní*/
SELECT ammo_boxes FROM armory ORDER BY a_base_id;

/*Č. 5, Vyberie všetkých vojakov, ktorí sú starši ako 25 ale mladší ako 30 alebo sú v aktivnej službe*/
SELECT * FROM soldier WHERE age > 25 AND age < 30 OR active = 1;

/*Č. 6, Vyberie všetkych vojakov, ktorí práve niesu vo službe*/
SELECT * FROM soldier WHERE active != 1;

/*Č. 7, Vyberie všetky základne, ktoré sa nachádzajú na abmieste začínajúcom na písmenko S*/
SELECT * FROM base WHERE location LIKE 'S%';
/*Č. 8, Vyberie všetky základne a vypíše počet koľko vojakov majú na základe tabuľky soldier*/
SELECT s_base_id, COUNT(*) AS pocet_vojakov FROM soldier GROUP BY s_base_id;

/*Č. 9, Vypíše ranky vojakov a k ním počet vojakov, ktorý majú daný rank + zoradí ich od najväčšieho po najmenši*/
SELECT s_rank, COUNT(*) AS pocet_vojakov FROM soldier GROUP BY s_rank ORDER BY s_rank DESC;

/*Č. 10, Spočita nám všetky ranky, ktoré sú v soldier a having vyberie len tie ktoré sú vyššie ako sergeant mayor (číslo 4)*/
SELECT s_rank, COUNT(*) AS pocet_vyssich_veliacich FROM soldier GROUP BY s_rank HAVING s_rank > 4;

/*Č. 11, Select nám vyberie vozidla a ich počet a na to joineme tabuľky vechicle a type a vyberieme vozidla s id menej ako 7*/
SELECT type AS vozidlo , COUNT(*) AS pocet_vozidiel FROM vechicle JOIN type ON t_id = v_type GROUP BY type HAVING type < 7;

/*Č. 12, Vypíše vek vojakov a k ním počet vojakov, ktorý majú daný vek (ak je menší ako 26) + zoradí ich od najväčšieho po najmenši*/
SELECT age, COUNT(*) AS pocet_vojakov FROM soldier JOIN vechicle ON soldier_id = s_id WHERE age < 26 
GROUP BY age DESC;

/*Č. 13,  Tento select vyberie všetkých s rolou grenadier*/
SELECT s_name, age, role FROM soldier JOIN t_role ON ro_id = s_role
WHERE s_role =(SELECT ro_id FROM t_role WHERE role = 'Grenadier');

/*Č. 14, Vypíše všetky vozidla (ich meno a condition) z krajiny ktorú zadáme*/
SELECT v_name, location, v_condition FROM vechicle JOIN base ON b_id = v_base_id
WHERE v_base_id =(SELECT b_id FROM base WHERE location = 'China');
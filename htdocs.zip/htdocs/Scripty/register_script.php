<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset-UTF-8">
        <title>Register_script</title>
</head>
<body>
    <?php
    if($_POST["ZHeslo"] != $_POST["Zheslo_check"] )
    {
      echo"Zadané heslo nie je zhodné";  
      
    };
   
?>
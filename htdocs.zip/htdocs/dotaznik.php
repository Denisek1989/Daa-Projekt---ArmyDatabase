<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset-UTF-8">
        <title>Login</title>
    </head>
   <body>
    <p>Vitaj!! Zadaj svoje meno a heslo.</p>
    
    <form method="POST" action="/Pages/login.php">
        <input name="Meno" type="text" /><br />
        <input name="Heslo" type="text" /><br />
        <input type="submit" value="Prihlas sa" />
    </form>
   </body>
</html>
CREATE TABLE `pouzivatelia` (
	`Id` INT(11) NOT NULL AUTO_INCREMENT,
	`Meno` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Priezvisko` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Email` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`Registracia` TIMESTAMP NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
	`Heslo` VARCHAR(255) NOT NULL COLLATE 'utf8mb4_general_ci',
	PRIMARY KEY (`Id`) USING BTREE
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
AUTO_INCREMENT=2
;
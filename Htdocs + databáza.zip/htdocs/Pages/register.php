
<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link rel="stylesheet" href="register.css">
</head>
<body>

    <form action="scrip_reg.php" method="POST" class="formular" >          
          <h1>Register</h1>
          <label for="meno"><b>Meno</b></label>
          <br>
          <input type="text" placeholder="Zadaj meno" name="meno" id="meno" required>
          <p>
          <label for="priezvisko"><b>Priezvisko</b></label>
          <br>
          <input type="text" placeholder="Zadaj priezvisko" name="priezvisko" id="priezvisko" required>
          <p>
          <label for="email"><b>Email</b></label>
          <br>
          <input type="mail" placeholder="Zadaj Email" name="email" id="email" required>
          <p>
          <label for="hesl"><b>Heslo</b></label>
          <br>
          <input type="heslo" placeholder="Zadaj heslo" name="hesl" id="hesl" required>
          <p>
          <label for="kontrolahesl"><b>Kontrola hesla</b></label>
          <br>
          <input type="heslo" placeholder="Znovu zadaj heslo" name="kontrolahesl" id="kontrolahesl" required>
 
        <p class="Buttonik">
          <button type="submit" class="regbtn">Registruj</button>
        </p>
        
        <div class="containersignin">
          <p>Už máš účet? <a href="login.php">Prihlas sa</a>.</p>
        </div>
      </form>
</body>
</html>